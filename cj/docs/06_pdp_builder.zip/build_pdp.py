# -*- coding: utf-8 -*-
# build_pdp.py v3 — 캐러셀 + 세로 상세 스토리 + 더보기 접기, 이미지 슬롯(placeholder 자동)
# 원칙: 설득 카피(SUBHEAD/ALTS/RESOLVE/BULLETS) 동결. 정보·이미지 리듬으로만 리얼리즘 상승. 3페이지 패리티.
import base64, os, io
from PIL import Image

UP = "/mnt/user-data/uploads/"

def b64(path, maxw=800):
    im = Image.open(path).convert("RGB")
    if im.size[0] > maxw:
        h = int(im.size[1] * maxw / im.size[0])
        im = im.resize((maxw, h), Image.LANCZOS)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=74, optimize=True)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()

def img_or_ph(path, label, ratio="1/1"):
    """파일이 있으면 <img>, 없으면 placeholder div를 반환."""
    if path and os.path.exists(path):
        return f'<img src="{b64(path)}" alt="{label}">'
    return (f'<div class="ph" style="aspect-ratio:{ratio};">'
            f'<div class="ph-in">📷<br>{label}<br><span>이미지 교체 예정</span></div></div>')

# ── 보유 이미지 ─────────────────────────────────────────────
PT_SQ   = UP + "ChatGPT_Image_2026년_6월_7일_오후_02_13_02.png"   # 팟타이 정사각(보유)
PT_W    = UP + "ChatGPT_Image_2026년_6월_7일_오후_02_12_32.png"   # 팟타이 가로(보유)
FR_SQ   = UP + "ChatGPT_Image_2026년_6월_7일_오후_02_14_48.png"   # 볶음밥 정사각(보유)
FR_W    = UP + "ChatGPT_Image_2026년_6월_7일_오후_02_15_38.png"   # 볶음밥 가로(보유)

# ── 신규 슬롯(생성해오면 아래 파일명으로 uploads에 두고 재빌드) ──
PT_PKG   = UP + "pt_package.png"    # 팟타이 패키지(정사각)
PT_CLOSE = UP + "pt_closeup.png"    # 팟타이 클로즈업(정사각)
PT_COMP  = "/home/claude/pt_components_fix.png"   # 라임·소품 제거 수정본 # 팟타이 구성품 펼침(가로)
PT_COOK  = UP + "pt_cooking.png"    # 팟타이 조리 과정(가로)
FR_PKG   = UP + "fr_package.png"
FR_CLOSE = UP + "fr_closeup.png"
FR_COMP  = UP + "fr_components.png"   # 최종(골든 톤·쌀알 개선)
FR_COOK  = UP + "fr_cooking.png"      # 최종(골든 톤·쌀알 개선)

GA_ID = "G-RZY2WEN4WR"

TEMPLATE = r"""<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>%%TITLE%%</title>
<link rel="stylesheet" as="style" crossorigin
 href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.min.css">
<script async src="https://www.googletagmanager.com/gtag/js?id=%%GA%%"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '%%GA%%');
</script>
<style>
  *{margin:0;padding:0;box-sizing:border-box;}
  body{font-family:"Pretendard",-apple-system,sans-serif;background:#fff;color:#191919;
       max-width:480px;margin:0 auto;font-size:15px;line-height:1.55;
       padding-bottom:calc(86px + env(safe-area-inset-bottom));}
  img{display:block;width:100%;}
  .ph{width:100%;background:linear-gradient(135deg,#f3f4f6,#e9ecef);display:flex;
      align-items:center;justify-content:center;color:#9aa0a6;}
  .ph-in{text-align:center;font-size:13px;font-weight:600;line-height:1.6;}
  .ph-in span{font-size:11px;color:#b9bec4;font-weight:400;}

  /* 헤더 */
  .hd{position:sticky;top:0;z-index:30;background:#fff;border-bottom:1px solid #f0f0f0;
      display:flex;align-items:center;justify-content:space-between;padding:12px 16px;}
  .hd .logo{font-weight:800;font-size:17px;letter-spacing:-0.3px;}
  .hd .logo .dot{color:#12b886;}
  .hd .badge{font-size:11px;color:#666;background:#f4f5f7;border:1px solid #e9ecef;
      padding:4px 8px;border-radius:20px;}

  /* 히어로 캐러셀 */
  .car{position:relative;}
  .car-track{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;
      -webkit-overflow-scrolling:touch;scrollbar-width:none;}
  .car-track::-webkit-scrollbar{display:none;}
  .car-track > *{flex:0 0 100%;scroll-snap-align:start;}
  .car .ribbon{position:absolute;top:12px;left:12px;background:rgba(255,255,255,.92);
      font-size:11px;font-weight:700;color:#0c8a66;padding:5px 9px;border-radius:6px;
      border:1px solid #d3f0e6;z-index:2;}
  .dots{position:absolute;bottom:10px;left:0;right:0;display:flex;gap:6px;justify-content:center;z-index:2;}
  .dots i{width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.55);
      border:1px solid rgba(0,0,0,.08);}
  .dots i.on{background:#12b886;}

  /* 상품 정보 */
  .info{padding:18px 16px 16px;}
  .brandline{font-size:12.5px;color:#8a8a8a;font-weight:600;margin-bottom:4px;}
  h1{font-size:20px;font-weight:800;letter-spacing:-0.4px;line-height:1.3;}
  .sub{font-size:14px;color:#555;margin-top:6px;}
  .starline{display:flex;align-items:center;gap:6px;margin-top:10px;font-size:12.5px;color:#999;}
  .starline .stars{color:#d9d9d9;letter-spacing:1.5px;font-size:13px;}
  .pricebox{margin-top:14px;display:flex;align-items:baseline;gap:6px;}
  .pricebox .won{font-size:24px;font-weight:800;letter-spacing:-0.5px;}
  .pricebox .cur{font-size:16px;font-weight:700;}
  .pricebox .unit{font-size:13px;color:#888;margin-left:2px;}
  .shipline{margin-top:12px;border-top:1px solid #f2f2f2;padding-top:12px;
      font-size:13px;color:#555;display:grid;gap:6px;}
  .shipline .row{display:flex;gap:8px;align-items:flex-start;}
  .shipline .ic{width:18px;text-align:center;flex:none;}
  .qtyrow{margin-top:14px;display:flex;align-items:center;justify-content:space-between;
      border:1px solid #e8e8e8;border-radius:10px;padding:10px 12px;}
  .qtyrow .lbl{font-size:13.5px;color:#555;}
  .qty{display:flex;align-items:center;border:1px solid #ddd;border-radius:8px;overflow:hidden;}
  .qty button{width:34px;height:32px;border:none;background:#fafafa;font-size:17px;color:#333;cursor:pointer;}
  .qty .n{width:40px;text-align:center;font-size:14.5px;font-weight:700;}

  .gap{height:8px;background:#f4f5f7;}
  .sec{padding:20px 16px;}
  .sec h2{font-size:16.5px;font-weight:800;letter-spacing:-0.3px;margin-bottom:14px;}

  /* 설득 블록(동결) */
  .blk-title{font-size:15px;font-weight:700;margin-bottom:12px;}
  .altcard{background:#fafafa;border:1px solid #f0f0f0;border-radius:10px;
      padding:11px 13px;margin-bottom:8px;}
  .altcard .lb{font-size:13px;font-weight:700;color:#444;}
  .altcard .tx{font-size:13.5px;color:#666;margin-top:3px;}
  .altcard strong{color:#191919;}
  .resolve{margin-top:14px;font-size:15px;line-height:1.6;background:#f0faf6;
      border:1px solid #d3f0e6;border-radius:10px;padding:13px 14px;}
  .resolve b{color:#0c8a66;}
  ul.feat{list-style:none;margin-top:14px;display:grid;gap:8px;}
  ul.feat li{font-size:14px;padding-left:24px;position:relative;}
  ul.feat li:before{content:"✓";position:absolute;left:2px;color:#12b886;font-weight:800;}

  /* 스펙 */
  table.spec{width:100%;border-collapse:collapse;font-size:13.5px;}
  table.spec th{width:96px;text-align:left;color:#888;font-weight:600;
      padding:9px 0;border-bottom:1px solid #f3f3f3;vertical-align:top;}
  table.spec td{padding:9px 0;border-bottom:1px solid #f3f3f3;color:#333;}

  /* 상세 스토리(접기) */
  .detail-wrap{position:relative;max-height:1100px;overflow:hidden;transition:max-height .35s ease;}
  .detail-wrap.open{max-height:none;}
  .detail-fade{position:absolute;bottom:0;left:0;right:0;height:120px;
      background:linear-gradient(transparent,#fff 78%);display:flex;align-items:flex-end;
      justify-content:center;padding-bottom:14px;}
  .detail-wrap.open .detail-fade{display:none;}
  .more-btn{background:#fff;border:1.5px solid #dcdcdc;border-radius:24px;
      font-size:14px;font-weight:700;color:#333;padding:11px 26px;cursor:pointer;font-family:inherit;}
  .dsec{padding:6px 0 22px;}
  .dsec .cap{padding:14px 16px 10px;}
  .dsec .cap .t{font-size:16px;font-weight:800;letter-spacing:-0.3px;}
  .dsec .cap .d{font-size:13.5px;color:#777;margin-top:4px;}

  /* 조리법 */
  .step{display:flex;gap:12px;margin-bottom:14px;align-items:flex-start;}
  .step .no{flex:none;width:24px;height:24px;border-radius:50%;background:#191919;color:#fff;
      font-size:12.5px;font-weight:800;display:flex;align-items:center;justify-content:center;margin-top:1px;}
  .step .tx{font-size:14px;color:#333;}
  .tip{margin-top:4px;font-size:12.5px;color:#888;background:#fafafa;border-radius:8px;padding:9px 11px;}

  .small{font-size:12.5px;color:#777;line-height:1.6;}
  .allergy{margin-top:10px;font-size:12.5px;color:#a8551f;background:#fff7ef;
      border:1px solid #f5e3cf;border-radius:8px;padding:9px 11px;}
  table.nutri{width:100%;border-collapse:collapse;font-size:12.5px;margin-top:10px;}
  table.nutri th,table.nutri td{border:1px solid #f0f0f0;padding:7px 6px;text-align:center;}
  table.nutri th{background:#fafafa;color:#666;font-weight:600;}
  .nutri-note{margin-top:6px;font-size:11.5px;color:#aaa;}
  ul.notice{list-style:none;display:grid;gap:7px;}
  ul.notice li{font-size:12.5px;color:#777;padding-left:14px;position:relative;}
  ul.notice li:before{content:"·";position:absolute;left:2px;}
  .revbox{background:#fafafa;border:1px dashed #e3e3e3;border-radius:12px;
      padding:26px 16px;text-align:center;color:#999;font-size:13.5px;}
  .revbox .big{font-size:22px;margin-bottom:6px;color:#d9d9d9;letter-spacing:2px;}
  details{border-top:1px solid #f1f1f1;}
  details:last-of-type{border-bottom:1px solid #f1f1f1;}
  summary{list-style:none;cursor:pointer;padding:14px 2px;font-size:14px;font-weight:600;
      display:flex;justify-content:space-between;align-items:center;}
  summary:after{content:"+";color:#bbb;font-size:17px;font-weight:400;}
  details[open] summary:after{content:"–";}
  details .ans{padding:0 2px 14px;font-size:13.5px;color:#666;}
  .foot{padding:18px 16px 26px;background:#fafafa;font-size:11.5px;color:#999;line-height:1.7;}

  .cta-bar{position:fixed;bottom:0;left:50%;transform:translateX(-50%);width:100%;max-width:480px;
      background:#fff;border-top:1px solid #ececec;display:flex;gap:8px;
      padding:10px 12px calc(10px + env(safe-area-inset-bottom));z-index:40;}
  .btn{flex:1;border:none;border-radius:10px;font-size:15px;font-weight:700;
      padding:13px 0;cursor:pointer;font-family:inherit;}
  .btn-notify{background:#fff;color:#0c8a66;border:1.5px solid #12b886;}
  .btn-buy{background:#12b886;color:#fff;}
  .btn:active{opacity:.85;}

  .overlay{position:fixed;inset:0;background:rgba(0,0,0,.45);display:none;
      align-items:center;justify-content:center;z-index:60;padding:24px;}
  .modal{background:#fff;border-radius:16px;max-width:340px;width:100%;padding:22px 20px;}
  .modal h3{font-size:16.5px;font-weight:800;margin-bottom:10px;}
  .modal p{font-size:14px;color:#555;margin-bottom:16px;}
  .modal .btn{width:100%;}
  .mlink{display:block;text-align:center;margin-top:12px;font-size:13px;color:#999;
      cursor:pointer;text-decoration:underline;}
  .mq .step-ind{font-size:12px;color:#12b886;font-weight:700;margin-bottom:8px;}
  .mq .q{font-size:14.5px;margin-bottom:14px;color:#333;}
  .opts{display:grid;gap:8px;}
  .opt{border:1.5px solid #e5e5e5;background:#fff;border-radius:10px;padding:12px;
      font-size:14.5px;font-weight:600;cursor:pointer;font-family:inherit;}
  .opt:active{border-color:#12b886;color:#0c8a66;}
</style>
</head>
<body>

<div class="hd">
  <div class="logo">오분식탁<span class="dot">.</span></div>
  <div class="badge">출시예정 · 사전 수요조사</div>
</div>

<!-- 히어로 캐러셀 -->
<div class="car">
  <div class="ribbon">신제품 출시 검토 중</div>
  <div class="car-track" id="heroCar">
    %%HERO_SLIDES%%
  </div>
  <div class="dots" id="heroDots"></div>
</div>

<div class="info">
  <div class="brandline">오분식탁</div>
  <h1>%%NAME%%</h1>
  <div class="sub">%%SUBHEAD%%</div>
  <div class="starline"><span class="stars">★★★★★</span><span>리뷰는 출시 후 공개됩니다</span></div>
  <div class="pricebox"><span class="won">%%PRICE%%</span><span class="cur">원</span><span class="unit">%%UNIT%%</span></div>
  <div class="shipline">
    <div class="row"><span class="ic">🚚</span><span><b>배송</b> · 출시 시 새벽배송/택배로 안내 예정</span></div>
    <div class="row"><span class="ic">🧊</span><span><b>유형</b> · 냉동식품 (-18℃ 보관)</span></div>
    <div class="row"><span class="ic">💳</span><span><b>안내</b> · 지금은 사전 수요조사 중으로, 결제가 진행되지 않습니다</span></div>
  </div>
  <div class="qtyrow">
    <span class="lbl">수량</span>
    <div class="qty">
      <button id="qtyMinus" aria-label="감소">−</button>
      <span class="n" id="qtyN">1</span>
      <button id="qtyPlus" aria-label="증가">+</button>
    </div>
  </div>
</div>

<div class="gap"></div>

<div class="sec">
  <div class="blk-title">%%BLKTITLE%%</div>
  %%ALTS%%
  <div class="resolve">%%RESOLVE%%</div>
  <ul class="feat">%%BULLETS%%</ul>
</div>

<div class="gap"></div>

<div class="sec">
  <h2>상품 정보</h2>
  <table class="spec">
    <tr><th>구성</th><td>%%SPEC_COMP%%</td></tr>
    <tr><th>내용량</th><td>%%SPEC_WEIGHT%%</td></tr>
    <tr><th>보관방법</th><td>냉동보관 (-18℃ 이하)</td></tr>
    <tr><th>조리시간</th><td>%%SPEC_TIME%%</td></tr>
    <tr><th>원산지</th><td>%%SPEC_ORIGIN%%</td></tr>
    <tr><th>출시</th><td>수요조사 후 확정 (알림 신청 시 우선 안내)</td></tr>
  </table>
</div>

<div class="gap"></div>

<!-- 상세 스토리 (접기) -->
<div class="detail-wrap" id="detailWrap">

  <div class="dsec">
    %%D_MOOD%%
    <div class="cap"><div class="t">%%CAP1_T%%</div><div class="d">%%CAP1_D%%</div></div>
  </div>

  <div class="dsec">
    %%D_CLOSE%%
    <div class="cap"><div class="t">%%CAP2_T%%</div><div class="d">%%CAP2_D%%</div></div>
  </div>

  <div class="dsec">
    %%D_COMP%%
    <div class="cap"><div class="t">%%CAP3_T%%</div><div class="d">%%CAP3_D%%</div></div>
  </div>

  <div class="dsec">
    %%D_COOK%%
    <div class="cap"><div class="t">%%CAP4_T%%</div><div class="d">%%CAP4_D%%</div></div>
  </div>

  <div class="sec" style="padding-top:4px;">
    <h2>조리법</h2>
    %%COOK%%
    <div class="tip">%%COOKTIP%%</div>
  </div>

  <div class="detail-fade"><button class="more-btn" id="btnMore">상세정보 펼쳐보기</button></div>
</div>

<div class="gap"></div>

<div class="sec">
  <h2>원재료 및 영양정보</h2>
  <div class="small">%%INGREDIENTS%%</div>
  <div class="allergy">⚠ 알레르기 유발물질: %%ALLERGY%%</div>
  <table class="nutri">
    <tr><th>열량</th><th>탄수화물</th><th>단백질</th><th>지방</th><th>나트륨</th></tr>
    <tr>%%NUTRI%%</tr>
  </table>
  <div class="nutri-note">1회 제공량 기준 · 출시 시 최종 확정되는 예정 수치입니다</div>
</div>

<div class="gap"></div>

<div class="sec">
  <h2>유의사항</h2>
  <ul class="notice">
    <li>해동 후 재냉동하지 마세요. 품질이 변할 수 있습니다.</li>
    <li>조리 직후 매우 뜨거우니 화상에 주의하세요.</li>
    <li>포장재 개봉 시 가장자리에 손이 베이지 않도록 주의하세요.</li>
    <li>본 페이지는 출시 전 수요조사용으로, 표기 정보는 출시 시 일부 변경될 수 있습니다.</li>
  </ul>
</div>

<div class="gap"></div>

<div class="sec">
  <h2>상품 리뷰</h2>
  <div class="revbox">
    <div class="big">☆ ☆ ☆ ☆ ☆</div>
    아직 작성된 리뷰가 없습니다.<br>리뷰는 <b>출시 후</b> 공개됩니다.
  </div>
</div>

<div class="gap"></div>

<div class="sec">
  <h2>자주 묻는 질문</h2>
  <details>
    <summary>%%FAQ1Q%%</summary>
    <div class="ans">%%FAQ1A%%</div>
  </details>
  <details>
    <summary>유통기한은 어떻게 되나요?</summary>
    <div class="ans">냉동 보관 기준 제조일로부터 9개월입니다. (출시 시 최종 확정)</div>
  </details>
  <details>
    <summary>언제 출시되나요?</summary>
    <div class="ans">현재 사전 수요조사 중이며, 조사 결과에 따라 출시 일정이 확정됩니다. <b>'출시되면 알려주세요'</b>를 눌러주시면 가장 먼저 안내드립니다.</div>
  </details>
</div>

<div class="foot">
  오분식탁 · 본 페이지는 <b>출시 전 사전 수요조사</b>를 위한 콘셉트 페이지입니다.<br>
  실제 판매·결제가 이루어지지 않으며, 개인정보를 수집하지 않습니다.<br>
  수집된 클릭 데이터는 수요조사 목적에만 사용 후 폐기됩니다.
</div>

<div class="cta-bar">
  <button class="btn btn-notify" id="btnNotify">출시되면 알려주세요</button>
  <button class="btn btn-buy" id="btnBuy">구매하기</button>
</div>

<div class="overlay" id="buyModal">
  <div class="modal">
    <h3>감사합니다 🙏</h3>
    <p>'%%NAME%%'는 현재 출시를 검토 중인 컨셉으로, 수요를 조사하고 있어요. 아직 실제 판매 전이라 <b>결제는 진행되지 않습니다.</b> 출시되면 가장 먼저 알려드릴까요?</p>
    <button class="btn btn-buy" id="btnNotifyFromBuy">출시되면 알려주세요</button>
    <span class="mlink" id="btnCloseBuy">관심만 표시하고 닫기</span>
  </div>
</div>

<div class="overlay" id="notifyModal">
  <div class="modal">
    <h3>관심 감사합니다 🙏</h3>
    <p>출시되면 알려드릴 수 있도록 준비하고 있어요. 여러분의 관심이 출시 결정에 큰 힘이 됩니다.</p>
    <button class="btn btn-buy" id="btnCloseNotify">닫기</button>
  </div>
</div>

<div class="overlay" id="miniOverlay" style="display:flex;">
  <div class="modal mq">
    <div id="mq1">
      <div class="step-ind">1 / 2</div>
      <h3>더 잘 맞는 정보를 보여드릴게요</h3>
      <div class="q">평소 집에서 식사는 보통 몇 분이서 하세요?</div>
      <div class="opts">
        <button class="opt" data-h="1인">혼자</button>
        <button class="opt" data-h="2인">둘</button>
        <button class="opt" data-h="3인+">셋 이상</button>
      </div>
    </div>
    <div id="mq2" style="display:none;">
      <div class="step-ind">2 / 2</div>
      <h3>거의 다 됐어요</h3>
      <div class="q">최근 2년간 동남아(태국·베트남 등) 여행 다녀오신 적 있나요?</div>
      <div class="opts">
        <button class="opt" data-t="yes">네</button>
        <button class="opt" data-t="no">아니오</button>
      </div>
    </div>
    <span class="mlink" id="btnSkip">건너뛰기</span>
  </div>
</div>

<script>
(function(){
  var PRODUCT = '%%PRODUCT%%';
  function ev(name, params){ try{ gtag('event', name, params||{}); }catch(e){} }
  function show(id){ var e=document.getElementById(id); if(e) e.style.display='flex'; }
  function hide(id){ var e=document.getElementById(id); if(e) e.style.display='none'; }
  function on(id, fn){ var e=document.getElementById(id); if(e) e.addEventListener('click', fn); }

  window.addEventListener('load', function(){ ev('pdp_view', {product:PRODUCT}); });

  // 히어로 캐러셀 닷
  var track = document.getElementById('heroCar');
  var dotsEl = document.getElementById('heroDots');
  if (track && dotsEl){
    var n = track.children.length;
    for (var i=0;i<n;i++){ var d=document.createElement('i'); if(i===0)d.className='on'; dotsEl.appendChild(d); }
    track.addEventListener('scroll', function(){
      var idx = Math.round(track.scrollLeft / track.clientWidth);
      Array.prototype.forEach.call(dotsEl.children, function(el,j){ el.className = (j===idx)?'on':''; });
    }, {passive:true});
  }

  // 상세정보 펼치기
  on('btnMore', function(){
    var w=document.getElementById('detailWrap'); if(w) w.classList.add('open');
  });

  // 수량(리얼리즘용 — 측정 무관)
  var qty=1, qn=document.getElementById('qtyN');
  on('qtyMinus', function(){ if(qty>1){qty--; qn.textContent=qty;} });
  on('qtyPlus',  function(){ if(qty<9){qty++; qn.textContent=qty;} });

  Array.prototype.forEach.call(document.querySelectorAll('#mq1 .opt'), function(b){
    b.addEventListener('click', function(){
      ev('mini_household', {value:b.getAttribute('data-h'), product:PRODUCT});
      hide('mq1'); var e=document.getElementById('mq2'); if(e) e.style.display='block';
    });
  });
  Array.prototype.forEach.call(document.querySelectorAll('#mq2 .opt'), function(b){
    b.addEventListener('click', function(){
      ev('mini_travel', {value:b.getAttribute('data-t'), product:PRODUCT});
      hide('miniOverlay');
    });
  });
  on('btnSkip', function(){ hide('miniOverlay'); });

  on('btnBuy', function(){ ev('buy_click', {product:PRODUCT}); show('buyModal'); });
  on('btnNotify', function(){ ev('notify_click', {product:PRODUCT}); show('notifyModal'); });
  on('btnNotifyFromBuy', function(){ ev('notify_click', {product:PRODUCT}); hide('buyModal'); show('notifyModal'); });
  on('btnCloseBuy', function(){ hide('buyModal'); });
  on('btnCloseNotify', function(){ hide('notifyModal'); });

  Array.prototype.forEach.call(document.querySelectorAll('.overlay'), function(o){
    o.addEventListener('click', function(e2){ if(e2.target===o) o.style.display='none'; });
  });
})();
</script>
</body>
</html>
"""

def alts(items):
    return "".join(
        f'<div class="altcard"><div class="lb">{lb}</div><div class="tx">{tx}</div></div>'
        for lb, tx in items)

def bullets(items):
    return "".join(f"<li>{b}</li>" for b in items)

def cook(steps):
    return "".join(
        f'<div class="step"><div class="no">{i+1}</div><div class="tx">{s}</div></div>'
        for i, s in enumerate(steps))

def hero_slides(paths_labels):
    return "".join(img_or_ph(p, lb, "1/1") for p, lb in paths_labels)

# ── 팟타이 공통(T1·T2 동일 — 같은 제품) ──
PADTHAI_COMMON = {
  "TITLE": "사르르 팟타이 | 오분식탁",
  "NAME": "사르르 팟타이",
  "PRICE": "7,500", "UNIT": "/ 1인분",
  "HERO_SLIDES": hero_slides([(PT_SQ,"대표 컷"), (PT_PKG,"패키지 컷"), (PT_CLOSE,"클로즈업 컷")]),
  "D_MOOD":  img_or_ph(PT_W,    "무드 컷(가로)", "3/2"),
  "D_CLOSE": img_or_ph(PT_CLOSE,"클로즈업 컷",   "1/1"),
  "D_COMP":  img_or_ph(PT_COMP, "구성품 펼침 컷(가로)", "3/2"),
  "D_COOK":  img_or_ph(PT_COOK, "조리 과정 컷(가로)",   "3/2"),
  "CAP1_T": "오늘 저녁, 팟타이가 식탁 위로",
  "CAP1_D": "별다른 준비 없이, 평일 저녁에도 부담 없는 한 그릇.",
  "CAP2_T": "탱글한 새우와 쫄깃한 쌀국수면",
  "CAP2_D": "국산 새우와 숙주·부추를 그대로 담았습니다.",
  "CAP3_T": "한 팩에 전부 들어있어요",
  "CAP3_D": "면 · 소스 · 건더기 · 땅콩 토핑까지, 따로 살 게 없습니다.",
  "CAP4_T": "끓는 물에 5분이면 완성",
  "CAP4_D": "물을 따라내고 소스에 비비기만 하면 끝.",
  "SPEC_COMP": "쌀국수면 1팩, 매실청 팟타이 소스 1팩, 건더기(새우·숙주·부추) 1팩, 땅콩 토핑 1봉, 크러시드 페퍼 1봉(맵기 선택)",
  "SPEC_WEIGHT": "380g (1인분)",
  "SPEC_TIME": "끓는 물 5분 / 전자레인지 5분",
  "SPEC_ORIGIN": "새우: 국산 / 쌀국수면: 태국산 / 매실청: 국산",
  "COOK": cook([
      "면·건더기 팩을 <b>봉지째</b> 끓는 물에 넣고 <b>5분</b> 데워주세요.",
      "팩을 꺼내 그릇에 담고, <b>소스 팩</b>을 부어 골고루 비벼주세요.",
      "동봉된 <b>땅콩 토핑</b>을 뿌리면 완성! (매콤하게 즐기려면 페퍼 토핑 추가)",
  ]),
  "COOKTIP": "TIP. 전자레인지 조리도 가능해요(내열용기, 700W 5분). 기호에 따라 숙주를 더하면 식감이 살아납니다.",
  "INGREDIENTS": "쌀국수면(태국산), 정제수, 매실청 7%(국산), 새우 12%(국산), 숙주, 부추, 양파, 마늘, 간장(대두·밀 함유), 설탕, 땅콩, 크러시드 레드페퍼, 식용유지류 등",
  "ALLERGY": "새우(갑각류), 땅콩, 대두, 밀 함유",
  "NUTRI": "<td>545kcal</td><td>78g</td><td>18g</td><td>16g</td><td>1,180mg</td>",
  "FAQ1Q": "전자레인지로도 조리할 수 있나요?",
  "FAQ1A": "네. 끓는 물 5분 조리를 권장하지만, 내열용기에 옮겨 전자레인지(700W) 5분으로도 조리하실 수 있어요.",
}

TEST = dict(PADTHAI_COMMON, **{
  "PRODUCT": "satll",
  "SUBHEAD": "사 먹어도 결국 손이 가던 팟타이 — 5분 끝판왕 등장.",
  "BLKTITLE": "이 맛, 지금 집에서 드시려면 —",
  "ALTS": alts([
    ("직접 만들기", "장 보고 손질하고, 볶는 데만 평균 <strong>40분 이상</strong>. 쓰고 남은 재료는 냉장고 행."),
    ("밀키트를 사도", "“굴소스 더 넣고, 프라이팬에 다시 볶고, 숙주는 따로 사서…” 결국 손이 <strong>한 번 더</strong> 가는 번거로움."),
    ("외식·배달", "한 그릇 <strong>15,000~20,000원</strong>."),
  ]),
  "RESOLVE": "<b>사르르 팟타이는, 끓는 물에 5분이면 끝.</b> 추가할 것도, 다시 볶을 것도 없이. <b>7,500원 — 외식의 절반.</b>",
  "BULLETS": bullets(["끓는 물 5분, 한 팩 완조리", "국산 새우·숙주·부추", "외식 수준 완성도", "매실청의 새콤함 (라임 없이)"]),
})

MAESIL = dict(PADTHAI_COMMON, **{
  "PRODUCT": "satll_maesil",
  "SUBHEAD": "타마린드 없이, 매실청으로 잡은 새콤함 — 부담 없는 진짜 팟타이.",
  "BLKTITLE": "팟타이는 먹고 싶은데, 이런 적 없으세요? —",
  "ALTS": alts([
    ("고수 향이 부담", "식당에서도 빼달라고 한 적이 있다."),
    ("피쉬소스(액젓) 향이 강하면", "특유의 향 때문에 손이 잘 안 간다."),
    ("타마린드", "새콤함의 핵심인데 어디서 사는지도 모르겠다."),
  ]),
  "RESOLVE": "<b>사르르 팟타이는 그 셋을 덜어냈어요.</b> 타마린드 대신 <b>매실청</b>으로 새콤함을 잡아, <b>고수·피쉬소스 부담 없이</b> 익숙한 입맛에. 그러면서 끓는 물에 5분이면 완성.",
  "BULLETS": bullets(["매실청의 새콤함 (타마린드·라임 없이)", "고수·피쉬소스 부담 없이", "끓는 물 5분, 한 팩 완조리", "국산 새우·숙주·부추"]),
})

CTRL = {
  "TITLE": "새우볶음밥 | 오분식탁",
  "PRODUCT": "control",
  "NAME": "새우볶음밥",
  "SUBHEAD": "혼밥 한 끼, 이걸로 끝 — 국산 새우 볶음밥 전자레인지 5분.",
  "PRICE": "5,500", "UNIT": "/ 1인분",
  "HERO_SLIDES": hero_slides([(FR_SQ,"대표 컷"), (FR_PKG,"패키지 컷"), (FR_CLOSE,"클로즈업 컷")]),
  "D_MOOD":  img_or_ph(FR_W,    "무드 컷(가로)", "3/2"),
  "D_CLOSE": img_or_ph(FR_CLOSE,"클로즈업 컷",   "1/1"),
  "D_COMP":  img_or_ph(FR_COMP, "구성품 펼침 컷(가로)", "3/2"),
  "D_COOK":  img_or_ph(FR_COOK, "조리 과정 컷(가로)",   "3/2"),
  "CAP1_T": "혼밥에도 제대로 된 한 끼",
  "CAP1_D": "별다른 준비 없이, 평일 저녁에도 부담 없는 한 그릇.",
  "CAP2_T": "탱글한 새우가 가득",
  "CAP2_D": "국산 새우와 야채를 고슬고슬한 밥에 그대로 볶았습니다.",
  "CAP3_T": "한 팩이면 준비 끝",
  "CAP3_D": "볶음밥 한 팩 — 따로 살 것도, 준비할 것도 없습니다.",
  "CAP4_T": "전자레인지 5분이면 완성",
  "CAP4_D": "데우고 골고루 섞기만 하면 끝.",
  "BLKTITLE": "혼밥 한 끼, 지금 챙기려면 —",
  "ALTS": alts([
    ("직접 만들기", "밥 짓고 새우 손질하고 볶고, 팬까지 닦으면 한참."),
    ("편의점·냉동", "새우는 몇 점뿐, “이게 다야?” 싶은 양."),
    ("배달", "한 그릇에 배달비까지."),
  ]),
  "RESOLVE": "<b>오분식탁 새우볶음밥은, 전자레인지 5분이면 끝.</b> 불도, 설거지도 없이. <b>5,500원 — 든든한 한 끼.</b>",
  "BULLETS": bullets(["전자레인지 5분, 한 팩 완성", "국산 새우 가득", "불 없이 간편하게", "1·2인 가구 한 끼로"]),
  "SPEC_COMP": "새우볶음밥 1팩",
  "SPEC_WEIGHT": "420g (1인분)",
  "SPEC_TIME": "전자레인지 5분 (700W)",
  "SPEC_ORIGIN": "새우: 국산 / 쌀: 국산",
  "COOK": cook([
      "봉지째 가볍게 흔들어 내용물을 풀어주세요.",
      "내열용기에 옮겨 <b>전자레인지(700W) 5분</b> 데워주세요.",
      "골고루 섞으면 완성!",
  ]),
  "COOKTIP": "TIP. 프라이팬에 한 번 더 볶으면 갓 볶은 식감이 살아납니다. 계란 후라이를 올리면 더 든든해요.",
  "INGREDIENTS": "쌀(국산), 새우 11%(국산), 당근, 완두콩, 옥수수, 대파, 간장(대두·밀 함유), 굴소스(굴 함유), 식용유지류 등",
  "ALLERGY": "새우(갑각류), 대두, 밀, 굴 함유",
  "NUTRI": "<td>485kcal</td><td>82g</td><td>14g</td><td>11g</td><td>980mg</td>",
  "FAQ1Q": "프라이팬으로도 조리할 수 있나요?",
  "FAQ1A": "네. 전자레인지 5분을 권장하지만, 식용유를 두른 프라이팬에 중불 6~7분 볶아도 맛있게 드실 수 있어요.",
}

def render(d):
    html = TEMPLATE.replace("%%GA%%", GA_ID)
    for k, v in d.items():
        html = html.replace("%%" + k + "%%", v)
    return html

for fname, d in [("pdp_test.html", TEST), ("pdp_test_maesil.html", MAESIL), ("pdp_control.html", CTRL)]:
    open("/home/claude/" + fname, "w", encoding="utf-8").write(render(d))
    print(fname, f"{os.path.getsize('/home/claude/'+fname)//1024}KB")
print("빌드 완료")
