#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
게이트 A — 네이버 공식 API (합법 수집)
준비: developers.naver.com → 애플리케이션 등록 → '검색' + '데이터랩(검색어트렌드)' API 사용 설정
      → Client ID / Secret 발급 후 아래에 입력 (또는 환경변수 NAVER_ID / NAVER_SECRET)

기능 1) datalab_trend()  : '냉동 팟타이' 등 편의-포맷 검색어의 2~3년 상대 추이 (편의 수요 우상향?)
기능 2) blog_collect()   : 블로그 후기 텍스트 수집 → reviews_naver.txt 저장 → 분류기에 투입
"""
import os, sys, json, urllib.request

CLIENT_ID = os.getenv("NAVER_ID", "여기에_CLIENT_ID")
CLIENT_SECRET = os.getenv("NAVER_SECRET", "여기에_CLIENT_SECRET")

def _headers(json_body=False):
    h = {"X-Naver-Client-Id": CLIENT_ID, "X-Naver-Client-Secret": CLIENT_SECRET}
    if json_body:
        h["Content-Type"] = "application/json"
    return h

# ---------- 1) 데이터랩 검색어트렌드 ----------
def datalab_trend(start="2023-01-01", end="2026-05-31", unit="month"):
    url = "https://openapi.naver.com/v1/datalab/search"
    body = {
        "startDate": start, "endDate": end, "timeUnit": unit,
        "keywordGroups": [
            {"groupName": "냉동 팟타이", "keywords": ["냉동 팟타이", "냉동팟타이"]},
            {"groupName": "밀키트 팟타이", "keywords": ["밀키트 팟타이", "팟타이 밀키트"]},
            {"groupName": "집에서 팟타이", "keywords": ["집에서 팟타이", "팟타이 만들기"]},
        ],
    }
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"),
                                 headers=_headers(json_body=True))
    res = json.loads(urllib.request.urlopen(req).read().decode("utf-8"))
    print("=== 데이터랩 검색어트렌드 (상대값 0~100) ===")
    for g in res["results"]:
        pts = g["data"]
        if not pts:
            print(f"[{g['title']}] 데이터 없음(검색량 미미)"); continue
        first = pts[0]["ratio"]; last = pts[-1]["ratio"]
        peak = max(p["ratio"] for p in pts)
        trend = "우상향↑" if last > first * 1.1 else ("우하향↓" if last < first * 0.9 else "보합→")
        print(f"[{g['title']}] 시작 {first:.1f} → 최근 {last:.1f} (피크 {peak:.1f}) · 추세 {trend}")
    # CSV로도 저장
    with open("datalab_trend.csv", "w", encoding="utf-8-sig") as f:
        f.write("group,date,ratio\n")
        for g in res["results"]:
            for p in g["data"]:
                f.write(f"{g['title']},{p['period']},{p['ratio']}\n")
    print("→ datalab_trend.csv 저장 (그래프/엑셀로 확인)")
    print("※ 상대값이라 절대 검색량 아님. '편의 포맷' 검색어가 의미있게 존재+보합/우상향이면 양성 신호.")

# ---------- 2) 블로그 후기 수집 → 분류기 투입 ----------
def blog_collect(queries=None, per_query=100, out="reviews_naver.txt"):
    queries = queries or ["냉동 팟타이 후기", "쿠캣 팟타이 후기", "풀무원 팟타이 후기", "밀키트 팟타이 후기"]
    seen, lines = set(), []
    for q in queries:
        for start in (1, 101):  # 최대 200건/쿼리
            url = (f"https://openapi.naver.com/v1/search/blog.json?"
                   f"query={urllib.parse.quote(q)}&display={per_query}&start={start}&sort=sim")
            try:
                res = json.loads(urllib.request.urlopen(
                    urllib.request.Request(url, headers=_headers())).read().decode("utf-8"))
            except Exception as e:
                print(f"[{q}] 요청 실패: {e}"); break
            for it in res.get("items", []):
                txt = (it["title"] + " " + it["description"])
                txt = txt.replace("<b>", "").replace("</b>", "").replace("&quot;", '"').replace("&amp;", "&")
                if txt not in seen:
                    seen.add(txt); lines.append(txt)
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"블로그 후기 {len(lines)}건 → {out} 저장")
    print(f"→ 이제: python gate_a_review_classifier.py {out}")
    print("※ 블로그는 광고성 글이 섞임 → 분류 후 예시 스니펫 눈으로 거를 것. 마켓 리뷰 표본과 함께 삼각.")

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    if CLIENT_ID.startswith("여기에"):
        print("⚠ 먼저 NAVER_ID / NAVER_SECRET 를 입력하세요 (developers.naver.com).")
        sys.exit(1)
    if cmd in ("trend", "all"):
        datalab_trend()
    if cmd in ("blog", "all"):
        print(); blog_collect()
