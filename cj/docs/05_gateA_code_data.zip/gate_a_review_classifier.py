#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
게이트 A — 리뷰 마이닝 분류기
사용법:
  1) 쿠캣/풀무원 등 '냉동·밀키트 팟타이' 리뷰를 읽고 복사 → reviews.txt (한 줄 = 한 리뷰)
     또는 reviews.csv (review 컬럼)
  2)  python gate_a_review_classifier.py reviews.txt
출력: 카테고리별 빈도 + '갭 언급률'(우리 제품이 메우는 불편 언급 비율) + 검증용 예시 스니펫
주의: 키워드 기반 정성 분류(표본 통계 아님). 정확도 위해 표본을 눈으로 검증할 것.
"""
import re, sys, csv, os
from collections import Counter, defaultdict

# --- 카테고리 사전 (PT 리뷰 분석에서 도출된 표현 기반) ---
CATEGORIES = {
    "자가보완_원물(완성도)": [r"추가해", r"더 넣", r"새우.{0,4}추가", r"고기.{0,4}추가",
                          r"야채.{0,4}추가", r"건더기.{0,4}(적|부족)", r"양\s*(이|도)?\s*적",
                          r"직접.{0,4}양념", r"숙주.{0,4}(넣|추가)", r"그제야"],
    "자가보완_편의침해": [r"따로.{0,4}사", r"직접.{0,4}구해", r"다시.{0,4}볶", r"프라이팬",
                       r"굴소스.{0,4}(추가|넣)", r"재료.{0,4}사", r"손이.{0,4}가"],
    "완성도/품질불만": [r"부족", r"아쉽", r"약하", r"단조", r"면.{0,3}(끊|불음|불었|퍼)",
                    r"별로", r"실망", r"맛이.{0,3}없"],
    "향신료부담": [r"고수", r"향신료", r"피쉬소스", r"향이.{0,3}(강|세|진)", r"느끼", r"비린"],
    "외식격차": [r"차라리.{0,4}외식", r"외식보다", r"외식.{0,3}(만|보다).{0,3}못",
              r"이\s*가격이?면.{0,4}외식"],
    "완조리수요(긍정)": [r"간편", r"5\s*분", r"데우(기|면)", r"간단", r"편하", r"집에서.{0,4}(먹|해)"],
    "재구매의심": [r"다시.{0,4}살지", r"재구매.{0,4}(글쎄|모르)", r"또.{0,3}살.{0,3}(까|지).{0,3}(모르|글쎄)", r"다신.{0,4}안"],
}
# 우리 제품(사르르 팟타이)이 직접 메우는 '갭' 카테고리
GAP_CATS = ["자가보완_원물(완성도)", "자가보완_편의침해", "완성도/품질불만"]

def load_reviews(path):
    if not os.path.exists(path):
        return None
    rows = []
    if path.endswith(".csv"):
        with open(path, encoding="utf-8-sig") as f:
            r = csv.DictReader(f)
            col = "review" if "review" in (r.fieldnames or []) else (r.fieldnames or [None])[0]
            rows = [(x.get(col) or "").strip() for x in r]
    else:
        with open(path, encoding="utf-8") as f:
            rows = [ln.strip() for ln in f]
    return [x for x in rows if x]

def classify(reviews):
    cat_counts = Counter()
    examples = defaultdict(list)
    gap_hit = 0
    per_review_cats = []
    for rv in reviews:
        hits = []
        for cat, pats in CATEGORIES.items():
            if any(re.search(p, rv) for p in pats):
                hits.append(cat)
                cat_counts[cat] += 1
                if len(examples[cat]) < 3:
                    examples[cat].append(rv[:60] + ("…" if len(rv) > 60 else ""))
        if any(c in GAP_CATS for c in hits):
            gap_hit += 1
        per_review_cats.append(hits)
    return cat_counts, examples, gap_hit, per_review_cats

def report(reviews):
    n = len(reviews)
    cat_counts, examples, gap_hit, _ = classify(reviews)
    print("=" * 70)
    print(f"게이트 A 리뷰 분석 — 표본 N = {n}")
    print("=" * 70)
    print("\n[카테고리별 언급률]  (한 리뷰가 여러 카테고리 가능)")
    for cat in CATEGORIES:
        c = cat_counts[cat]
        bar = "█" * round(c / max(n, 1) * 30)
        star = " ★갭" if cat in GAP_CATS else ""
        print(f"  {cat:<18} {c:>3}건 ({c/max(n,1)*100:4.1f}%) {bar}{star}")
    print("\n[★ 게이트 A 판정 지표]")
    print(f"  갭 언급률 = {gap_hit}/{n} = {gap_hit/max(n,1)*100:.1f}%")
    print(f"  (우리 제품이 메우는 불편 — 자가보완·완성도불만 — 을 언급한 리뷰 비율)")
    print(f"  → 사전등록 양성 기준: ≥ 15%  ⇒  {'양성 ✅' if gap_hit/max(n,1) >= 0.15 else '음성 ❌'}")
    print("\n[검증용 예시 스니펫] (키워드 오탐 눈으로 확인할 것)")
    for cat in CATEGORIES:
        if examples[cat]:
            print(f"  · {cat}:")
            for ex in examples[cat]:
                print(f"      “{ex}”")
    print("\n※ 키워드 기반 정성 분류. 표본 통계 아님. 표본을 눈으로 검증하고,")
    print("  더 정확히 하려면 LFM(LLM) 분류 프롬프트 병용 권장(키트 문서 참조).")

# --- 작동 검증용 합성 샘플 (실제 파일 없을 때) ---
SAMPLE = [
    "맛은 괜찮은데 새우랑 야채를 직접 추가해야 그제야 만족스러워요",
    "건더기가 너무 적어서 숙주 따로 사서 넣었어요",
    "굴소스 더 넣고 프라이팬에 다시 볶으니 먹을 만하더라구요",
    "고수 향이 너무 강해서 좀 느끼하고 비린 맛이 났어요",
    "이 가격이면 차라리 외식하는 게 나을 듯",
    "간편하게 5분이면 되니까 자취생한테 좋아요",
    "면이 좀 불어서 아쉬웠고 소스도 단조로웠어요",
    "다시 살지는 모르겠네요 그냥 그래요",
    "양이 적어서 남자가 먹기엔 부족해요",
    "집에서 간단하게 데워 먹기 좋아요",
    "맛있어요 재구매 의사 있습니다",
    "직접 양념해서 고기 추가하면 그나마 괜찮아요",
]

if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else None
    reviews = load_reviews(path) if path else None
    if reviews is None:
        print(f"[알림] 입력 파일 없음 → 합성 샘플 {len(SAMPLE)}건으로 작동 검증 실행\n")
        reviews = SAMPLE
    report(reviews)
