import numpy as np
rng = np.random.default_rng(7)

# ---------- Wilson half-width helper ----------
def wilson_hw(p, n, z=1.96):
    if n == 0: return np.nan
    denom = 1 + z*z/n
    center = (p + z*z/(2*n)) / denom
    half = (z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))) / denom
    return half  # approx half-width

# ---------- DEMAND DECISION (test vs control) ----------
# rule: r_hat = p_test_hat / p_ctrl_hat ; GO if >=0.70, KILL if <0.35, else PIVOT
def demand_decision(n_test, n_ctrl, p_test, p_ctrl, trials=20000):
    xt = rng.binomial(n_test, p_test, trials)
    xc = rng.binomial(n_ctrl, p_ctrl, trials)
    pt = xt/n_test
    pc = np.where(xc==0, 1e-9, xc/n_ctrl)
    r = pt/pc
    go = np.mean(r>=0.70)
    kill = np.mean(r<0.35)
    piv = 1-go-kill
    return go, piv, kill

def true_bucket(r):
    if r>=0.70: return "GO"
    if r<0.35: return "KILL"
    return "PIVOT"

# ---------- SEGMENT DIRECTION ----------
def segment_dir(n_test, share_hi, p_hi, p_lo, trials=20000):
    # among test clicks, hi-segment share, compare buy-rates
    n_hi = rng.binomial(n_test, share_hi, trials)
    n_lo = n_test - n_hi
    n_hi = np.clip(n_hi,1,None); n_lo=np.clip(n_lo,1,None)
    x_hi = rng.binomial(n_hi, p_hi); x_lo = rng.binomial(n_lo, p_lo)
    ph = x_hi/n_hi; pl = x_lo/n_lo
    dir_correct = np.mean(ph>pl) if p_hi>p_lo else np.mean(pl>ph)
    # two-proportion z test
    pooled = (x_hi+x_lo)/(n_hi+n_lo)
    se = np.sqrt(pooled*(1-pooled)*(1/n_hi+1/n_lo))
    se = np.where(se==0,1e-9,se)
    z = (ph-pl)/se
    sig = np.mean(np.abs(z)>1.96)
    return dir_correct, sig

# ---------- SCENARIOS ----------
CPC = 500
budgets = {"Lean ₩200k":200000, "Lean+ ₩300k":300000, "Mid ₩450k":450000, "Full ₩900k":900000}
test_share, ctrl_share = 0.65, 0.35   # of clicks
p_ctrl_base = 0.12                      # control (known-demand) buy-click rate

print("="*88)
print("CPC=%d원 가정.  clicks_total=budget/CPC.  test:control = 65:35" % CPC)
print("control(기성 검증제품) 구매클릭률 = %.0f%%" % (p_ctrl_base*100))
print("="*88)

# DEMAND: sweep true ratio r = p_test/p_ctrl
ratios = [1.00, 0.85, 0.70, 0.50, 0.35, 0.15]
print("\n[A] 수요 GO/KILL 판정 정확도  (true ratio = 제품수요/대조군)")
print("    각 칸 = P(GO) / P(PIVOT) / P(KILL).  굵은 게 정답 버킷이어야 맞음.")
header = "true r |真버킷| " + " | ".join(f"{b:>11}" for b in budgets)
print(header); print("-"*len(header))
for r in ratios:
    p_test = r*p_ctrl_base
    tb = true_bucket(r)
    row = f"{r:>5.2f} | {tb:>4} | "
    cells=[]
    for b,amt in budgets.items():
        N = amt/CPC
        nt = int(N*test_share); nc=int(N*ctrl_share)
        go,piv,kill = demand_decision(nt,nc,p_test,p_ctrl_base)
        cells.append(f"{go*100:2.0f}/{piv*100:2.0f}/{kill*100:2.0f}")
    print(row + " | ".join(f"{c:>11}" for c in cells))

# Probability of CORRECT demand call per budget (avg over a realistic mix)
print("\n[A2] '올바른 수요 판정' 확률 (정답 버킷에 떨어질 확률)")
mix = {1.00:"강수요",0.85:"양호",0.70:"경계",0.50:"약함",0.35:"futility",0.15:"사망"}
print("scenario | " + " | ".join(f"{b:>11}" for b in budgets))
for r,name in mix.items():
    p_test=r*p_ctrl_base; tb=true_bucket(r)
    cells=[]
    for b,amt in budgets.items():
        N=amt/CPC; nt=int(N*test_share); nc=int(N*ctrl_share)
        go,piv,kill=demand_decision(nt,nc,p_test,p_ctrl_base)
        correct = {"GO":go,"PIVOT":piv,"KILL":kill}[tb]
        cells.append(f"{correct*100:9.0f}%")
    print(f"{name:>8}(r={r:.2f}) | " + " | ".join(cells))

# CI width on test buy-rate
print("\n[A3] 제품 구매클릭률 추정 정밀도 (Wilson 반폭, p_test=8% 가정)")
print("budget | test클릭수 | ±정밀도")
for b,amt in budgets.items():
    N=amt/CPC; nt=int(N*test_share)
    hw=wilson_hw(0.08,nt)
    print(f"{b:>11} | {nt:>9} | ±{hw*100:.1f}%p")

# SEGMENT direction
print("\n[B] 세그먼트 '방향성' 정확도 & '유의성' 확률")
print("    여행세그 비중 25%, 기저 구매율 ~9%.  ratio=고세그/저세그")
seg_ratios=[2.0,1.5,1.25,1.0]
print("seg ratio | metric | " + " | ".join(f"{b:>11}" for b in budgets))
for sr in seg_ratios:
    p_lo=0.09; p_hi=p_lo*sr
    dir_cells=[]; sig_cells=[]
    for b,amt in budgets.items():
        N=amt/CPC; nt=int(N*test_share)
        d,s=segment_dir(nt,0.25,p_hi,p_lo)
        dir_cells.append(f"{d*100:9.0f}%"); sig_cells.append(f"{s*100:9.0f}%")
    print(f"{sr:>9.2f} | 방향맞춤 | " + " | ".join(dir_cells))
    print(f"{'':>9} | 유의(p<.05) | " + " | ".join(sig_cells))

# FUTILITY early-kill at 150 clicks: risk of killing a GOOD product
print("\n[C] 무용성 조기-KILL(150클릭 시점) 위험 점검")
print("    규칙: 150클릭서 제품률<대조군의35%면 KILL. 진짜 강수요(r=1.0)를 잘못 죽일 확률은?")
for r,name in [(1.0,"강수요"),(0.85,"양호"),(0.70,"경계"),(0.35,"진짜futility")]:
    p_test=r*p_ctrl_base
    # at 150 test clicks, estimate p_test_hat; control assumed known ~0.12 (use ctrl est too)
    nt=150; nc=int(150*ctrl_share/test_share)
    xt=rng.binomial(nt,p_test,30000); pt=xt/nt
    xc=rng.binomial(nc,p_ctrl_base,30000); pc=np.where(xc==0,1e-9,xc/nc)
    early_kill=np.mean(pt/pc<0.35)
    print(f"  {name:>10}(r={r:.2f}): 조기KILL 발동확률 = {early_kill*100:.1f}%")

# CPC sensitivity for the key demand call (borderline-ish r=0.85, 'correct GO' prob)
print("\n[D] CPC 민감도 — '양호 수요(r=0.85)'를 GO로 맞출 확률")
print("budget | CPC300 | CPC500 | CPC900")
for b,amt in budgets.items():
    cells=[]
    for cpc in [300,500,900]:
        N=amt/cpc; nt=int(N*test_share); nc=int(N*ctrl_share)
        go,piv,kill=demand_decision(nt,nc,0.85*p_ctrl_base,p_ctrl_base)
        cells.append(f"{go*100:5.0f}%")
    print(f"{b:>11} | " + " | ".join(cells))
print("\n[done]")
