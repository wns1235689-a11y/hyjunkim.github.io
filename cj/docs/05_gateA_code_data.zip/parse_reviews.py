#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os, re, glob

RATING_MAP = {"좋음":"5★", "보통":"3★", "별로":"2★", "나쁨":"1★", "나뽑":"1★", "나쁘":"1★"}
NOISE = ["사진/동영상","판매자","이 상품 품질","도움이 돼요","도움 안돼요","도움이돼요","신고하기",
         "맛 만족도","간편함","조리가 간편","상품 리뷰","명 이상","명 만족","광고","로켓프레시",
         "로켓배송","100g","1009","1000","와우할인","할인","원)","무료배송","쿠팡(주)"]
DATE = re.compile(r"\d{4}\s*[.\-]\s*\d{1,2}\s*[.\-]\s*\d{1,2}")
PRODNAME = re.compile(r"쿠[캣켓컷]|팟타이\s*\(냉동\)|냉동\),?\s*\d")
STARJUNK = re.compile(r"^[\s습술슬솔홈촉촉춤솜홈\^\*※\.\,\[\]\(\)_=<>ㅣ｜·`'\"~+\-/\\|0-9]{0,8}$")

def is_noise(l):
    if any(k in l for k in NOISE): return True
    if DATE.search(l): return True
    if PRODNAME.search(l): return True
    hangul = len(re.findall(r"[가-힣]", l))
    if hangul < 2: return True            # 한글 거의 없는 줄(별점·기호·광고숫자)
    nonh = len(re.findall(r"[^\s가-힣.,!?~%()]", l))
    if nonh > hangul: return True          # 한글보다 잡기호가 많은 줄
    return False

def find_rating(prev_lines):
    for l in reversed(prev_lines[-4:]):
        for k,v in RATING_MAP.items():
            if l.strip().startswith(k) or l.strip()==k:
                return v
    return "?"

reviews = []
for path in sorted(glob.glob("ocr/*.txt")):
    base = os.path.basename(path)
    if base in ("01.txt","06.txt","14.txt"):  # 제품 이미지 페이지
        continue
    lines = [l.rstrip() for l in open(path, encoding="utf-8")]
    i = 0
    while i < len(lines):
        if "판매자" in lines[i] or PRODNAME.search(lines[i]):
            rating = find_rating(lines[:i])
            j = i+1
            # 제품명 줄 건너뛰기
            while j < len(lines) and (PRODNAME.search(lines[j]) or not lines[j].strip()):
                j += 1
            body = []
            stop = ["이 상품 품질","맛 만족도","간편함","도움이 돼요","상품 리뷰","명 이상","명 만족"]
            while j < len(lines) and not any(s in lines[j] for s in stop):
                if not is_noise(lines[j]):
                    body.append(lines[j].strip())
                j += 1
            text = " ".join(body).strip()
            text = re.sub(r"\s+"," ",text)
            if len(re.findall(r"[가-힣]", text)) >= 6:   # 의미있는 본문만
                reviews.append((base, rating, text))
            i = j
        else:
            i += 1

with open("reviews_raw.txt","w",encoding="utf-8") as f:
    for src,r,t in reviews:
        f.write(f"[{src}|{r}] {t}\n")

print(f"추출된 리뷰 후보: {len(reviews)}개\n")
for src,r,t in reviews:
    print(f"[{r}] {t[:90]}{'…' if len(t)>90 else ''}")
