#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import re
from collections import Counter, defaultdict

raw = [l.rstrip("\n") for l in open("reviews_raw.txt", encoding="utf-8")]

# ---- 본문만 추출 (앞의 [src|rating] 태그 제거) ----
def strip_tag(l):
    return re.sub(r"^\[[^\]]*\]\s*", "", l)

# ---- 제품명/잡음 프리픽스 제거 ----
PREFIX = [
    r"생어거스[틴팀]\s*새우\s*\S*\s*팟타이,?\s*\d+,?\s*\d*\s*팩?",
    r"쿠[캣켓컷]\s*팟타이\s*\(냉동\),?\s*\d+\w*,?\s*\d*\s*개?",
    r"상품명\s*:?\s*\S*\s*\S*\s*팟타이\s*\S*\s*인분",
    r"애[슐숄]리\s*\S*\s*팟타이\s*\S*\s*인분",
    r"맨위로", r"쿠팡실구매자",
]
def clean(l):
    l = strip_tag(l)
    for p in PREFIX:
        l = re.sub(p, " ", l)
    l = re.sub(r"신선도\s*_?\s*\S+\s*\S*해?요?\.?$", "", l)   # 끝의 신선도 태그
    l = re.sub(r"장바구니\s*담기\s*바로구매", "", l)
    l = re.sub(r"\([^)]*\d{2,}[^)]*\)", " ", l)                # (1,495) 등
    l = re.sub(r"[가-힣]\*[가-힣]", " ", l)                     # 이*선 등 이름
    l = re.sub(r"\s+", " ", l).strip()
    return l

# ---- 잡음 줄 판별 ----
def is_junk(l):
    if len(re.findall(r"[가-힣]", l)) < 6: return True
    if re.search(r"습습|솔술|술술습|숍|☆|★", l): return True
    nonh = len(re.findall(r"[^\s가-힣.,!?~%()ㅎㅜㅠ]", l))
    if nonh > len(re.findall(r"[가-힣]", l)) * 0.6: return True
    return False

cleaned, seen = [], set()
for l in raw:
    c = clean(l)
    if not c or is_junk(c): continue
    key = c[:25]
    if key in seen: continue
    seen.add(key); cleaned.append(c)

open("reviews_clean.txt","w",encoding="utf-8").write("\n".join(cleaned))

# ---- 카테고리 ----
CATS = {
  "자가보완·원물추가": [r"추가", r"더\s*넣", r"넣으면", r"집에\s*있던", r"좋아하는\s*재료", r"햄도", r"넣어"],
  "조리번거로움·자가보완(편의)": [r"손이\s*많이", r"귀찮", r"번거", r"후라이?펜", r"프라이팬", r"다시\s*볶", r"요리과정", r"조리법", r"어려", r"순서대로", r"쉽지\s*않", r"눌러?붙", r"늘러붙"],
  "완성도불만(양·면·소스)": [r"양이?\s*(적|너무\s*적|작)", r"양도\s*적", r"1\.5인분", r"인분.*?(작|적)", r"면이?\s*(퍼|너무|불)", r"소스가?\s*(밍밍|한쪽|적)", r"골고루\s*(안|잘\s*안)", r"부족", r"숙주도?\s*조금"],
  "외식격차(집밥<외식)": [r"차라리", r"사먹는\s*게", r"배달시", r"음식점", r"식당", r"매장", r"파는\s*게", r"가게맛", r"외식"],
  "정통맛이질": [r"현지", r"태국에서", r"흉내", r"원래\s*알던", r"아는\s*팟타이\s*맛이\s*아", r"무슨\s*맛", r"내맛도"],
  "단맛과다": [r"달아", r"너무\s*달", r"디저트만큼", r"달달", r"달콤"],
  "QC·산패·신선도": [r"묵은내", r"쩐", r"쩌", r"째", r"펀내", r"군내", r"산화", r"오래된\s*\S*냄새", r"상했", r"신선하지", r"숙주가?\s*얼", r"계란\s*(터|흰자)", r"역해", r"사료\s*냄새", r"썩"],
  "향신료부담": [r"고수", r"피쉬소스", r"향신료", r"향이?\s*(강|세|진)", r"느끼", r"비린"],
  "재구매의심": [r"다시\s*안\s*살", r"또\s*(시|사|살).{0,3}않", r"재구매.{0,3}(안|없|글쎄|모르)", r"다신\s*안"],
}
GAP = ["자가보완·원물추가","조리번거로움·자가보완(편의)","완성도불만(양·면·소스)","외식격차(집밥<외식)"]

counts = Counter(); examples = defaultdict(list); gap_hit = 0
for rv in cleaned:
    hits = []
    for cat, pats in CATS.items():
        if any(re.search(p, rv) for p in pats):
            hits.append(cat); counts[cat]+=1
            if len(examples[cat])<3: examples[cat].append(rv[:70])
    if any(h in GAP for h in hits): gap_hit += 1

n = len(cleaned)
print("="*72)
print(f"게이트 A ② 리뷰 분석 — 정제 후 N = {n}  (쿠캣 냉동 + 생어거스틴·애슐리 밀키트)")
print("="*72)
print("\n[카테고리별 언급률]")
for cat in CATS:
    c = counts[cat]; bar="█"*round(c/max(n,1)*40); star=" ★우리갭" if cat in GAP else ""
    print(f"  {cat:<22} {c:>3} ({c/max(n,1)*100:4.1f}%) {bar}{star}")
print(f"\n[★ 판정 지표] 갭 언급률(우리 제품이 메우는 불편) = {gap_hit}/{n} = {gap_hit/max(n,1)*100:.1f}%")
print(f"   사전등록 양성 기준 ≥15%  ⇒  {'양성 ✅' if gap_hit/max(n,1)>=0.15 else '음성 ❌'}")
print("\n[대표 스니펫]")
for cat in CATS:
    if examples[cat]:
        print(f"  · {cat}")
        for e in examples[cat]: print(f"      “{e}”")
